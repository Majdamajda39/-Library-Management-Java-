
import java.util.ArrayList;
import java.util.Scanner;

public class LibrarySystem {
    private ArrayList<String> books = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void run() {
        while (true) {
            System.out.println("\n1. عرض الكتب");
            System.out.println("2. إضافة كتاب");
            System.out.println("3. حذف كتاب");
            System.out.println("4. خروج");
            System.out.print("اختر خياراً: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline
            switch (choice) {
                case 1:
                    showBooks();
                    break;
                case 2:
                    addBook();
                    break;
                case 3:
                    deleteBook();
                    break;
                case 4:
                    System.out.println("تم الخروج.");
                    return;
                default:
                    System.out.println("خيار غير صالح.");
            }
        }
    }

    private void showBooks() {
        if (books.isEmpty()) {
            System.out.println("لا توجد كتب.");
        } else {
            System.out.println("الكتب:");
            for (int i = 0; i < books.size(); i++) {
                System.out.println((i + 1) + ". " + books.get(i));
            }
        }
    }

    private void addBook() {
        System.out.print("أدخل اسم الكتاب: ");
        String book = scanner.nextLine();
        books.add(book);
        System.out.println("تمت الإضافة.");
    }

    private void deleteBook() {
        showBooks();
        System.out.print("أدخل رقم الكتاب للحذف: ");
        int index = scanner.nextInt() - 1;
        scanner.nextLine(); // consume newline
        if (index >= 0 && index < books.size()) {
            books.remove(index);
            System.out.println("تم الحذف.");
        } else {
            System.out.println("رقم غير صالح.");
        }
    }
}
