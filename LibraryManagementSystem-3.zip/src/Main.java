
public class Main {
    public static void main(String[] args) {
        Library library = new Library();

        Book book1 = new Book("Java Basics", "Ali Ahmed", "1111");
        Book book2 = new Book("OOP Concepts", "Fatima Khalid", "2222");
        Borrower borrower = new Borrower("Sara");

        library.addBook(book1);
        library.addBook(book2);

        System.out.println("Available books:");
        library.listBooks();

        library.borrowBook("1111", borrower);
        library.returnBook("1111");

        System.out.println("Books after transaction:");
        library.listBooks();
    }
}
