import java.util.Scanner;

public class LibrarySystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Book book1 = new Book("Java Basics", "John Doe", "111");
        Book book2 = new Book("Data Structures", "Jane Smith", "222");

        Borrower borrower = new Borrower("أحمد");

        while (true) {
            System.out.println("\n1. عرض الكتب");
            System.out.println("2. استعارة كتاب");
            System.out.println("3. إرجاع كتاب");
            System.out.println("4. عرض الكتب المستعارة");
            System.out.println("5. خروج");
            System.out.print("اختر خياراً: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    book1.displayInfo();
                    book2.displayInfo();
                    break;
                case 2:
                    System.out.print("أدخل رقم الكتاب (1 أو 2): ");
                    int b = scanner.nextInt();
                    borrower.borrow(b == 1 ? book1 : book2);
                    break;
                case 3:
                    System.out.print("أدخل رقم الكتاب (1 أو 2): ");
                    int r = scanner.nextInt();
                    borrower.returnBook(r == 1 ? book1 : book2);
                    break;
                case 4:
                    borrower.listBorrowedBooks();
                    break;
                case 5:
                    System.out.println("وداعاً!");
                    return;
                default:
                    System.out.println("خيار غير صالح.");
            }
        }
    }
}
