
import java.util.*;

public class Library {
    private List<Book> books = new ArrayList<>();

    public void addBook(Book book) {
        books.add(book);
    }

    public void listBooks() {
        for (Book book : books) {
            System.out.println(book);
        }
    }

    public void borrowBook(String isbn, Borrower borrower) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn) && book.isAvailable()) {
                book.borrowBook();
                System.out.println(borrower.getName() + " borrowed " + book.getTitle());
                return;
            }
        }
        System.out.println("Book not available or not found.");
    }

    public void returnBook(String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn) && !book.isAvailable()) {
                book.returnBook();
                System.out.println("Book " + book.getTitle() + " returned.");
                return;
            }
        }
        System.out.println("Book not found or not borrowed.");
    }
}
